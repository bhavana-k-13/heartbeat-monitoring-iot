"""Run with:  python -m unittest discover -s tests -v   (from the project folder)"""
import os, sys, tempfile, unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["HEARTBEAT_DB"] = _tmp.name  # use a throw-away DB for tests

from app import create_app, database as db  # noqa: E402
from app.classifier import classify  # noqa: E402


class ClassifierTests(unittest.TestCase):
    def test_boundaries(self):
        cases = {72: "NORMAL", 60: "NORMAL", 100: "NORMAL", 59: "WARNING", 50: "WARNING",
                 101: "WARNING", 120: "WARNING", 49: "CRITICAL", 121: "CRITICAL", 30: "CRITICAL", 200: "CRITICAL"}
        for bpm, expected in cases.items():
            with self.subTest(bpm=bpm):
                self.assertEqual(classify(bpm), expected)


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = create_app().test_client()
        db.clear_all()

    def test_health(self):
        self.assertEqual(self.client.get("/api/health").status_code, 200)

    def test_post_normal_no_alert(self):
        r = self.client.post("/api/readings", json={"bpm": 75})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.json["status"], "NORMAL")
        self.assertIsNone(r.json["alert"])
        self.assertEqual(self.client.get("/api/alerts").json, [])

    def test_post_warning_creates_alert(self):
        r = self.client.post("/api/readings", json={"bpm": 110})
        self.assertEqual(r.json["status"], "WARNING")
        a = self.client.get("/api/alerts").json
        self.assertEqual(len(a), 1)
        self.assertIn("SIMULATED", a[0]["response_action"])

    def test_post_critical_creates_alert(self):
        r = self.client.post("/api/readings", json={"bpm": 40})
        self.assertEqual(r.json["status"], "CRITICAL")
        self.assertEqual(self.client.get("/api/alerts").json[0]["level"], "CRITICAL")

    def test_validation_errors(self):
        bad = [{}, {"bpm": "abc"}, {"bpm": None}, {"bpm": True}, {"bpm": 5}, {"bpm": 999}, {"bpm": -10}, {"bpm": [1]}]
        for body in bad:
            with self.subTest(body=body):
                self.assertEqual(self.client.post("/api/readings", json=body).status_code, 400)
        self.assertEqual(self.client.post("/api/readings", data="not json").status_code, 400)
        self.assertEqual(self.client.get("/api/readings").json, [])  # nothing stored

    def test_numeric_string_accepted(self):
        self.assertEqual(self.client.post("/api/readings", json={"bpm": "80"}).status_code, 201)

    def test_latest_and_history(self):
        self.assertEqual(self.client.get("/api/latest").status_code, 404)
        for v in (70, 80, 90):
            self.client.post("/api/readings", json={"bpm": v})
        self.assertEqual(self.client.get("/api/latest").json["bpm"], 90)
        hist = self.client.get("/api/readings?limit=2").json
        self.assertEqual([h["bpm"] for h in hist], [80, 90])
        self.assertEqual(self.client.get("/api/readings?limit=x").status_code, 400)

    def test_stats(self):
        for v in (70, 110, 40):
            self.client.post("/api/readings", json={"bpm": v})
        s = self.client.get("/api/stats").json
        self.assertEqual(s["total"], 3)
        self.assertEqual(s["by_status"], {"NORMAL": 1, "WARNING": 1, "CRITICAL": 1})
        self.assertEqual(s["alerts"], 2)
        self.assertEqual((s["min_bpm"], s["max_bpm"]), (40, 110))

    def test_simulator_one_shot(self):
        r = self.client.post("/api/simulate/next", json={"mode": "tachycardia"})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.json["source"], "simulator")
        self.assertEqual(self.client.post("/api/simulate/next", json={"mode": "bogus"}).status_code, 400)

    def test_auto_simulator_start_stop(self):
        self.assertTrue(self.client.post("/api/simulate/start", json={"mode": "normal"}).json["running"])
        self.assertTrue(self.client.get("/api/simulate/status").json["running"])
        self.assertFalse(self.client.post("/api/simulate/stop").json["running"])

    def test_clear(self):
        self.client.post("/api/readings", json={"bpm": 40})
        self.client.delete("/api/readings")
        self.assertEqual(self.client.get("/api/readings").json, [])
        self.assertEqual(self.client.get("/api/alerts").json, [])

    def test_dashboard_page(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Heartbeat Monitoring", r.data)


if __name__ == "__main__":
    unittest.main()
