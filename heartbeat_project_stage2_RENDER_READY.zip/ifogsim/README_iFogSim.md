# iFogSim part (SEPARATE from the Flask application)

**Important honesty note:** these simulations are NOT integrated into the live Flask app.
They model how heartbeat data *could* be processed on edge / fog / cloud nodes.

## Why fog computing here?
Alerts must be decided quickly. Sending every reading to a distant cloud adds WAN delay and traffic.
A nearby fog gateway can classify readings and raise alerts locally, and send only abnormal records
and summaries to the cloud for storage. (This is the idea being simulated.)

| File | What it is | Verified? |
|---|---|---|
| `standalone/SimpleFogSim.java` | Dependency-free Java model: cloud-only vs fog-assisted | YES - compiled and run, output in `standalone_output.txt` |
| `ifogsim2/HeartbeatFogSim.java` | Real iFogSim2 program (Sensor -> Edge -> Fog -> Cloud) | NO - written from the iFogSim2 API, not compiled by the author (no iFogSim jars available) |

## A) Run SimpleFogSim on Windows 11 (easy, 3 steps)
1. Install JDK 17 or newer (e.g. Temurin from adoptium.net). Choose the option to add to PATH.
2. Open the `ifogsim\standalone` folder, click the address bar, type `cmd`, Enter.
3. Run:  `java SimpleFogSim.java`
Expected: a table with Cloud-only vs Fog-assisted average latency and WAN traffic
(author's run: ~255.8 ms vs ~18.0 ms, WAN traffic reduction ~68.9%). Numbers come from assumed delays at the top of the file.
Error `'java' is not recognized` -> JDK not on PATH; reinstall and reopen cmd.

## B) Run HeartbeatFogSim in real iFogSim2 (needs an IDE; may need small fixes)
1. Install JDK 17+ and **IntelliJ IDEA Community** (or Eclipse).
2. Download the iFogSim repository: https://github.com/Cloudslab/iFogSim (Download ZIP, unzip; use the iFogSim2 version).
3. Open the unzipped folder as a project in IntelliJ (it has the required jars in its `jars` folder; add them to the project libraries if the IDE asks).
4. Copy `ifogsim2/HeartbeatFogSim.java` into `src/org/fog/test/perfeval/`.
5. Right-click `HeartbeatFogSim` -> Run. If compile errors appear, they are most likely import or constructor
   differences between iFogSim versions; compare with `VRGameFog.java` in the same folder (it is the reference example).
6. Report honestly in your viva: if it did not run, say "the iFogSim model is prepared; the standalone model is the verified one."
