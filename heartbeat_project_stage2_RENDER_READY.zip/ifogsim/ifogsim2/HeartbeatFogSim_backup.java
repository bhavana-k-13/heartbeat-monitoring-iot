package org.fog.test.perfeval;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.Application;
import org.fog.application.selectivity.FractionalSelectivity;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.TimeKeeper;
import org.fog.utils.distribution.DeterministicDistribution;

/**
 * HeartbeatFogSim - iFogSim2 model of the heartbeat monitoring data flow.
 * Topology:  Sensor -> Edge (wearable) -> Fog gateway -> Cloud
 *   clientModule     runs on EDGE   (receives BPM, shows alert)
 *   classifierModule runs on FOG    (NORMAL/WARNING/CRITICAL decision)
 *   storageModule    runs on CLOUD  (long-term storage)
 *
 * STATUS: written against the iFogSim2 API but NOT compiled or run by the author
 * (no iFogSim jars were available). Expect to fix small import/signature issues.
 * This is a SEPARATE simulation. It is NOT connected to the Flask application.
 */
public class HeartbeatFogSim {
    static List<FogDevice> fogDevices = new ArrayList<FogDevice>();
    static List<Sensor> sensors = new ArrayList<Sensor>();
    static List<Actuator> actuators = new ArrayList<Actuator>();
    static int numOfPatients = 3;   // change to scale the experiment

    public static void main(String[] args) {
        Log.printLine("Starting HeartbeatFogSim...");
        try {
            Log.disable();
            int num_user = 1;
            Calendar calendar = Calendar.getInstance();
            boolean trace_flag = false;
            CloudSim.init(num_user, calendar, trace_flag);

            String appId = "heartbeat_app";
            FogBroker broker = new FogBroker("broker");

            Application application = createApplication(appId, broker.getId());
            application.setUserId(broker.getId());

            createFogDevices(broker.getId(), appId);

            ModuleMapping moduleMapping = ModuleMapping.createModuleMapping();
            moduleMapping.addModuleToDevice("storageModule", "cloud");
            moduleMapping.addModuleToDevice("classifierModule", "fog-gateway");
            for (FogDevice d : fogDevices) {
                if (d.getName().startsWith("edge-")) {
                    moduleMapping.addModuleToDevice("clientModule", d.getName());
                }
            }

            Controller controller = new Controller("master-controller", fogDevices, sensors, actuators);
            controller.submitApplication(application, 0,
                    new ModulePlacementMapping(fogDevices, application, moduleMapping));

            TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());
            CloudSim.startSimulation();
            CloudSim.stopSimulation();
            Log.printLine("HeartbeatFogSim finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happened");
        }
    }

    private static void createFogDevices(int userId, String appId) {
        FogDevice cloud = createFogDevice("cloud", 44800, 40000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25);
        cloud.setParentId(-1);
        fogDevices.add(cloud);

        FogDevice fog = createFogDevice("fog-gateway", 2800, 4000, 10000, 10000, 1, 0.0, 107.339, 83.4333);
        fog.setParentId(cloud.getId());
        fog.setUplinkLatency(100);          // fog -> cloud WAN latency (ms)
        fogDevices.add(fog);

        for (int i = 0; i < numOfPatients; i++) {
            FogDevice edge = createFogDevice("edge-" + i, 500, 1000, 10000, 10000, 2, 0.0, 87.53, 82.44);
            edge.setParentId(fog.getId());
            edge.setUplinkLatency(5);       // edge -> fog LAN latency (ms)
            fogDevices.add(edge);

            Sensor sensor = new Sensor("s-" + i, "BPM_READING", userId, appId, new DeterministicDistribution(1000));
            sensor.setApp(null);
            sensors.add(sensor);
            sensor.setGatewayDeviceId(edge.getId());
            sensor.setLatency(1.0);

            Actuator display = new Actuator("a-" + i, userId, appId, "ALERT_DISPLAY");
            actuators.add(display);
            display.setGatewayDeviceId(edge.getId());
            display.setLatency(1.0);
        }
    }

    private static FogDevice createFogDevice(String nodeName, long mips, int ram, long upBw, long downBw,
                                             int level, double ratePerMips, double busyPower, double idlePower) {
        List<Pe> peList = new ArrayList<Pe>();
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips)));
        int hostId = FogUtils.generateEntityId();
        long storage = 1000000;
        int bw = 10000;
        PowerHost host = new PowerHost(hostId, new RamProvisionerSimple(ram), new BwProvisionerOverbooking(bw),
                storage, peList, new StreamOperatorScheduler(peList), new FogLinearPowerModel(busyPower, idlePower));
        List<Host> hostList = new ArrayList<Host>();
        hostList.add(host);

        FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
                "x86", "Linux", "Xen", host, 10.0, 3.0, 0.05, 0.001, 0.0);
        FogDevice fogdevice = null;
        try {
            fogdevice = new FogDevice(nodeName, characteristics, new AppModuleAllocationPolicy(hostList),
                    new LinkedList<Storage>(), 10, upBw, downBw, 0, ratePerMips);
        } catch (Exception e) {
            e.printStackTrace();
        }
        fogdevice.setLevel(level);
        return fogdevice;
    }

    @SuppressWarnings({"serial"})
    private static Application createApplication(String appId, int userId) {
        Application application = Application.createApplication(appId, userId);

        application.addAppModule("clientModule", 10);
        application.addAppModule("classifierModule", 10);
        application.addAppModule("storageModule", 10);

        // addAppEdge(source, destination, cpuLength, nwLength, tupleType, direction, edgeType)
        application.addAppEdge("BPM_READING", "clientModule", 100, 200, "BPM_READING", Tuple.UP, AppEdge.SENSOR);
        application.addAppEdge("clientModule", "classifierModule", 500, 200, "RAW_BPM", Tuple.UP, AppEdge.MODULE);
        application.addAppEdge("classifierModule", "storageModule", 1000, 100, "STATUS_RECORD", Tuple.UP, AppEdge.MODULE);
        application.addAppEdge("classifierModule", "clientModule", 100, 100, "ALERT", Tuple.DOWN, AppEdge.MODULE);
        application.addAppEdge("clientModule", "ALERT_DISPLAY", 50, 100, "ALERT_DISPLAY", Tuple.DOWN, AppEdge.ACTUATOR);

        application.addTupleMapping("clientModule", "BPM_READING", "RAW_BPM", new FractionalSelectivity(1.0));
        application.addTupleMapping("classifierModule", "RAW_BPM", "STATUS_RECORD", new FractionalSelectivity(0.3));
        application.addTupleMapping("classifierModule", "RAW_BPM", "ALERT", new FractionalSelectivity(0.3));
        application.addTupleMapping("clientModule", "ALERT", "ALERT_DISPLAY", new FractionalSelectivity(1.0));

        // Control loop whose latency we care about: sensor -> edge -> fog -> edge -> display
        final AppLoop alertLoop = new AppLoop(new ArrayList<String>() {{
            add("BPM_READING"); add("clientModule"); add("classifierModule"); add("clientModule"); add("ALERT_DISPLAY");
        }});
        List<AppLoop> loops = new ArrayList<AppLoop>() {{ add(alertLoop); }};
        application.setLoops(loops);
        return application;
    }
}
