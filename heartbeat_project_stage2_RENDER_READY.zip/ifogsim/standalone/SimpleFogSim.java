import java.util.Random;

/**
 * SimpleFogSim - a small, dependency-free Java model that compares
 *   (A) CLOUD-ONLY processing   vs   (B) FOG-ASSISTED processing
 * of heartbeat readings.  It is NOT iFogSim and NOT connected to the Flask app.
 * All latency/size values below are ILLUSTRATIVE ASSUMPTIONS, not measurements.
 *
 * Run (Java 11+):   java SimpleFogSim.java
 */
public class SimpleFogSim {
    // ---- assumptions (milliseconds / bytes) ----
    static final int SENSORS = 10, READINGS_PER_SENSOR = 300;   // 1 reading/sec for 5 min
    static final double LAN_MS = 5, LAN_JITTER = 3;              // sensor/display <-> fog gateway
    static final double WAN_MS = 100, WAN_JITTER = 40;           // gateway <-> cloud (one way)
    static final double FOG_PROC_MS = 5, CLOUD_PROC_MS = 2;
    static final int RAW_BYTES = 200, ALERT_BYTES = 100, SUMMARY_BYTES = 100, SUMMARY_EVERY = 10;

    // same demo thresholds as the Flask app
    static String classify(int bpm) {
        if (bpm < 50 || bpm > 120) return "CRITICAL";
        if (bpm < 60 || bpm > 100) return "WARNING";
        return "NORMAL";
    }

    // same "mixed" pattern as app/simulator.py
    static int nextBpm(Random r) {
        double x = r.nextDouble(), b;
        if (x < 0.70) b = 75 + 8 * r.nextGaussian();
        else if (x < 0.85) b = r.nextBoolean() ? 110 + 5 * r.nextGaussian() : 55 + 2 * r.nextGaussian();
        else b = r.nextBoolean() ? 135 + 8 * r.nextGaussian() : 44 + 3 * r.nextGaussian();
        return (int) Math.max(20, Math.min(250, Math.round(b)));
    }

    static double lan(Random r) { return LAN_MS + r.nextDouble() * LAN_JITTER; }
    static double wan(Random r) { return WAN_MS + r.nextDouble() * WAN_JITTER; }

    public static void main(String[] args) {
        Random rnd = new Random(42);   // fixed seed -> repeatable results
        int total = SENSORS * READINGS_PER_SENSOR;
        int[] bpms = new int[total];
        for (int i = 0; i < total; i++) bpms[i] = nextBpm(rnd);

        // ---------- A) cloud only ----------
        Random ra = new Random(1);
        double sumA = 0, maxA = 0; long wanBytesA = 0; int alerts = 0;
        for (int bpm : bpms) {
            wanBytesA += RAW_BYTES;                                  // every reading goes to the cloud
            if (!classify(bpm).equals("NORMAL")) {
                alerts++;
                double lat = lan(ra) + wan(ra) + CLOUD_PROC_MS + wan(ra) + lan(ra);
                sumA += lat; maxA = Math.max(maxA, lat);
                wanBytesA += ALERT_BYTES;                            // alert returns over WAN
            }
        }
        // ---------- B) fog assisted ----------
        Random rb = new Random(1);
        double sumB = 0, maxB = 0; long wanBytesB = 0;
        int[] perSensor = new int[SENSORS];
        for (int i = 0; i < total; i++) {
            int bpm = bpms[i], s = i % SENSORS;
            String st = classify(bpm);
            if (!st.equals("NORMAL")) {
                double lat = lan(rb) + FOG_PROC_MS + lan(rb);        // alert decided locally at fog
                sumB += lat; maxB = Math.max(maxB, lat);
                wanBytesB += RAW_BYTES;                              // abnormal record archived in cloud
            }
            if (++perSensor[s] % SUMMARY_EVERY == 0) wanBytesB += SUMMARY_BYTES; // periodic summary
        }

        System.out.println("SimpleFogSim (illustrative model - NOT iFogSim, NOT the Flask app)");
        System.out.printf("Sensors=%d, readings=%d, abnormal readings (alerts)=%d%n", SENSORS, total, alerts);
        System.out.println("----------------------------------------------------------------");
        System.out.printf("%-26s %14s %14s%n", "Metric", "Cloud-only", "Fog-assisted");
        System.out.printf("%-26s %14.1f %14.1f%n", "Avg alert latency (ms)", sumA / alerts, sumB / alerts);
        System.out.printf("%-26s %14.1f %14.1f%n", "Max alert latency (ms)", maxA, maxB);
        System.out.printf("%-26s %14d %14d%n", "WAN traffic (bytes)", wanBytesA, wanBytesB);
        System.out.printf("%-26s %14s %13.1f%%%n", "WAN traffic reduction", "-", 100.0 * (wanBytesA - wanBytesB) / wanBytesA);
        System.out.println("Values depend on the assumptions at the top of the file.");
    }
}
